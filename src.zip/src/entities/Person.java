package entities;

import java.io.Serializable;

public enum Person implements Serializable {
    ATTENDEE, ORGANIZER, SPEAKER, VIP
}
