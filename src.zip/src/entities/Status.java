package entities;

import java.io.Serializable;

public enum Status implements Serializable {
    PENDING, RESOLVED
}
