package entities;

import java.io.Serializable;

public enum SubmenuSwitch implements Serializable {
    ON, OFF
}
